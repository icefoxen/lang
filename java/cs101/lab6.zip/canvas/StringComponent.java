package canvas;
import javax.swing.*;

/**
 * StringComponent.java
 *
 * A component containing a String to be drawn on a CS101Canvas.
 * Created: Wed Sep 01 11:28:31 1999
 *
 * @author Kenneth J. Goldman
 * @version 1.0
 */
public class StringComponent extends JLabel {

  /**
   * Creates a StringComponent at the given position that is
   * just large enough for the given text.
   *
   * @param x the x coordinate of the upper left corner
   * @param y the y coordinate of the upper left corner
   * @param text the 'String' to be displayed
   */
  public StringComponent(int x, int y, String text) {
    super(text);
    setBounds(x,y,getPreferredSize().width,getPreferredSize().height);
  }

  /**
   * Changes the text of the component and updates the
   * size of the component to fit it.
   *
   * @param text the new text
   */
  public void setText(String text) {
    super.setText(text);
    setSize(getPreferredSize());
  }
} // StringComponent
