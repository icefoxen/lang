package canvas;

/**
 * ShapeComponent.java
 *
 *
 * Created: Mon Aug 30 17:14:53 1999
 *
 * @author Kenneth J. Goldman 
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;

/**
 * This class encapsulates a Shape to be drawn on the CS101Canvas.
 */
public class ShapeComponent extends JComponent {
    private Shape shape;
    private boolean filled;

  /**
   * Creates a ShapeComponent for the given Shape.
   * The shape will be drawn in black and will not be filled.
   *
   * @param shape any 'Shape'
   */
  public ShapeComponent(Shape shape) {
    this(shape,false,Color.black);
  }
  /**
   * Creates a ShapeComponent for the given Shape.
   * The shape will be drawn in black.
   *
   * @param shape any 'Shape'
   * @param filled whether or not to fill in the shape
   */
  public ShapeComponent(Shape shape, boolean filled) {
    this(shape,filled,Color.black);
  }
  /**
   * Creates a ShapeComponent for the given Shape.
   * The shape will not be filled in.
   *
   * @param shape any 'Shape'
   * @param c the color to be used to draw the shape
   */
  public ShapeComponent(Shape shape, Color c) {
    this(shape,false,c);
  }
  /**
   * Creates a ShapeComponent for the given Shape.
   *
   * @param shape any 'Shape'
   * @param filled whether or not to fill the shape with color
   * @param c the color with which to draw the shape
   */
  public ShapeComponent(Shape shape, boolean filled, Color c) {
    this.shape = shape;
    this.filled = filled;
    setForeground(c);
    updateBounds();
  }

  /**
   * Gets the shape for this component
   */
  public Shape getShape() {
    return shape;
  }

  /**
   * Sets whether or not to fill the shape when drawing.
   *
   * @param filled whether or not to fill the shape when drawing.
   */
  public void setFilled(boolean filled) {
    this.filled = filled;
    repaint();
  }

  synchronized void updateBounds() {
    setBounds(shape.getBounds().x,shape.getBounds().y,
	      shape.getBounds().width+1,shape.getBounds().height+1);
    repaint();
  }

  /**
   * For discovering the "best" width and height of the component.
   *
   * @return a 'Dimension' object encapsulating the preferred width and height
   */
  public Dimension getPreferredSize() {
    return getSize();
  }

  /**
   * Paints the component.
   *
   * @param g the graphics context in which to draw
   */
  public synchronized void paint(Graphics g) {
    Graphics2D g2 = (Graphics2D) g;
    g2.setColor(getForeground());
    g2.translate(-shape.getBounds().x,-shape.getBounds().y);
    if (filled) {
      g2.fill(shape);
    } else {
      g2.draw(shape);
    }
  }

  public String toString() {
    String name = shape.toString();
    String bounds = getBounds().toString();
    try {
      return name.substring(name.lastIndexOf('.')+1,name.indexOf('@')) 
	+ " in " + bounds.substring(bounds.indexOf('['));
    }
    catch (Exception e) {
      return name + " in " + bounds.substring(bounds.indexOf('['));
    }
  }
}



