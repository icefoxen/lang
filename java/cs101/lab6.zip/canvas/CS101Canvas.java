package canvas;

/**
 * CS101Canvas.java
 *
 * This class provides support for drawing shapes in a window,
 * and for being notified about mouse motion and mouse clicks.
 *
 * Created: Wed Sep 01 16:33:41 1999
 *
 * @author Kenneth J. Goldman 
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.*;
import java.applet.*;

public class CS101Canvas extends JFrame {
  JLayeredPane drawingPanel;
  Label feedbackLabel;
  EventSupport mouseMotionSupport;
  EventSupport mouseClickSupport;
  LocalListener mouseListener;
  HashMap movingComponentsMap;
  Set movingComponents;
  final int movingDelay = 50;
  boolean closed = false;
  static Applet applet;
  static HashMap clips;
 
  static class FreeFormLayout implements LayoutManager {
        FreeFormLayout() {}
        public void addLayoutComponent(String name, Component comp) {}
        public void removeLayoutComponent(Component comp) {}
        public Dimension preferredLayoutSize(Container parent) {
	  Dimension size = parent.getSize();
	  Rectangle result = new Rectangle(0,0,size.width,size.height);
	  Component[] comps = parent.getComponents();
	  for (int i = 0; i < comps.length; i++)
	    result = result.union(comps[i].getBounds());
	  return new Dimension(result.width,result.height);
	  //return new Dimension(parent.getSize());
        }
        public Dimension minimumLayoutSize(Container parent) {
            return preferredLayoutSize(parent);
        }
        public void layoutContainer(Container parent) {}
  }

  public static void setApplet(Applet app) {
    applet = app;
    if (clips == null)
      clips = new HashMap();
  }

  public static Applet getApplet() {
    return applet;
  }

  public void playSound(final String file) {
    if (applet != null)
      (new Thread() {
	public void run() {
	  //synchronized (clips) {
	    try {
	      if (!clips.containsKey(file))
		clips.put(file, applet.getAudioClip(applet.getDocumentBase(),file));
	      
	      ((AudioClip) clips.get(file)).play();
	    } catch (Exception e) {
	      System.out.println("CS101Canvas: couldn't play sound " + file +
				 " due to " + e);
	    }
	//}
	}
      }).start();
  }
      
  /**
   * Creates a CS101Canvas with a white background that is initially
   * 640 pixels wide and 480 pixels high.
   */
  public CS101Canvas() {
    this("CS101Canvas", Color.white, 640, 480);
  }

  public CS101Canvas(String title, Color background, int width, int height) {
    this(title,background,width,height,true);
  }

  public CS101Canvas(String title) {
    this(title, Color.white, 640, 480);
  }

  /**
   * Creates a canvas with the given title, background color, and size.
   *
   * @param title a value of type 'String'
   * @param background a value of type 'Color'
   * @param width a value of type 'int'
   * @param height a value of type 'int'
   * @param resizable a value of type 'boolean'
   */
  public CS101Canvas(String title, Color background, int width, int height,
		     boolean resizable) {
    super(title);
    DataView.reset();
    getContentPane().setLayout(new BorderLayout());
  
    drawingPanel = new JLayeredPane();
    drawingPanel.setSize(width,height);
    drawingPanel.setLayout(new FreeFormLayout());

    JViewport view = new JViewport();
    view.setSize(width,height);
    view.add(drawingPanel);

    drawingPanel.setOpaque(true);
    if (resizable) {  // provide scroll panes and feedback
      getContentPane().add(new JScrollPane(view), BorderLayout.CENTER);
      getContentPane().add(feedbackLabel = new Label(), BorderLayout.SOUTH); 
    }
    else {
      getContentPane().add(view, BorderLayout.CENTER);
    }

    movingComponentsMap = new HashMap();
    movingComponents = movingComponentsMap.entrySet();
    
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
	closed = true;
	dispose();
	if (applet == null)
	  System.exit(0);
      }
    });

    Class[] twoInts = {int.class, int.class};
    mouseListener = new LocalListener();
    mouseMotionSupport = new EventSupport("mouseMovedTo",twoInts);
    mouseClickSupport = new EventSupport("mouseClickedAt",twoInts);
    drawingPanel.addMouseMotionListener(mouseListener);
    drawingPanel.addMouseListener(mouseListener);
    setBackground(background);
    pack();
    show();
    setResizable(resizable);
    (new Thread() { public void run() {moveComponentsAsNeeded();}}).start();
  }

  public boolean isOpen() {
    return !closed;
  }

  public void setCursor(Cursor c) {
    super.setCursor(c);
    drawingPanel.setCursor(c);
  }

  public void setBackground(Color c) {
    super.setBackground(c);
    getContentPane().setBackground(c);
    if (drawingPanel != null)
      drawingPanel.setBackground(c);
  }

  /**
   * Draws an object and reference diagram for the given data
   * structure on the canvas.  The objects can be moved around by
   * dragging them with the mouse.  References are shown by lines.
   *
   * @param data the data structure to draw
   */
  public void showData(final Object data) {
    if (data == null)
      System.out.println("WARNING: The CS101Canvas cannot display a null data structure.");
    try {
    EventQueue.invokeAndWait(new Runnable() {
    	public void run() {
			new DataView(data, CS101Canvas.this);
    	}
    });
    } catch (Exception e) {
    		e.printStackTrace();
    }
  }

  /**
   * Tells the canvas that the given listener object wants to be informed
   * whenever the mouse moves on the canvas.
   *
   * @param listener any object that provides a mouseMovedTo method with
   * two int parameters for the new x and y location of the mouse 
   */
  public synchronized void addMousePositionListener(Object listener) {
    mouseMotionSupport.addListener(listener);
  }

  /**
   * Tells the canvas that the given object no longer wants to be informed
   * about mouse motion.
   *
   * @param listener the object no longer interested in listening
   */
  public synchronized void removeMousePositionListener(Object listener) {
    mouseMotionSupport.removeListener(listener);
  }

  /**
   * Tells the canvas that the given listener object wants to be informed
   * whenever the mouse is clicked on the canvas.
   *
   * @param listener any object that provides a mouseClickedAt method with
   * two int parameters for the x and y location where the mouse was clicked
   */
  public synchronized void addMouseClickListener(Object listener) {
    mouseClickSupport.addListener(listener);
  }

  /**
   * Tells the canvas that the given object no longer wants to be informed
   * about mouse clicks.
   *
   * @param listener the object no longer interested in listening
   */
  public synchronized void removeMouseClickListener(Object listener) {
    mouseClickSupport.removeListener(listener);
  }
    
  class LocalListener implements MouseListener, MouseMotionListener { 
    /**
     * The Java event loop calls this method when the mouse is clicked.
     * Users of the CS101Canvas typically will not need to use this method.
     *
     * @param param1 a value of type 'MouseEvent'
     */
  public synchronized void mouseClicked(MouseEvent param1) {
  }
  /**
   * The Java event loop calls this method when the mouse enters the canvas.
   * Users of the CS101Canvas typically will not need to use this method.
   *
   * @param param1 a value of type 'MouseEvent'
   */
  public synchronized void mouseEntered(MouseEvent param1) {
    if (feedbackLabel != null)
      feedbackLabel.setText(param1.getSource().toString());
  }
  /**
   * The Java event loop calls this method when the mouse leaves the canvas.
   * Users of the CS101Canvas typically will not need to use this method.
   *
   * @param param1 a value of type 'MouseEvent'
   */
  public synchronized void mouseExited(MouseEvent param1) {
    if (feedbackLabel != null)
      feedbackLabel.setText("");
  }
  /**
   * The Java event loop calls this method when a mouse key is pressed.
   * Users of the CS101Canvas typically will not need to use this method.
   *
   * @param param1 a value of type 'MouseEvent'
   */
  public synchronized void mousePressed(MouseEvent param1) {
    Point p = ((Component) param1.getSource()).getLocation();
    Object[] params = {new Integer(p.x + param1.getX()), new Integer(p.y + param1.getY())};
    mouseClickSupport.notify(params);
  }
  /**
   * The Java event loop calls this method when the a mouse key is released.
   * Users of the CS101Canvas typically will not need to use this method.
   *
   * @param param1 a value of type 'MouseEvent'
   */
  public synchronized void mouseReleased(MouseEvent param1) {
  }
  /**
   * The Java event loop calls this method when the mouse is dragged.
   * Users of the CS101Canvas typically will not need to use this method.
   *
   * @param e a value of type 'MouseEvent'
   */
  public synchronized void mouseDragged(MouseEvent e) {
    Point p = ((Component) e.getSource()).getLocation();
    Object[] params = {new Integer(p.x + e.getX()), new Integer(p.y + e.getY())};
    mouseMotionSupport.notify(params);
  }
    /**
   * The Java event loop calls this method when the mouse is moved.
   * Users of the CS101Canvas typically will not need to use this method.
   *
   * @param e a value of type 'MouseEvent'
   */
  public synchronized void mouseMoved(MouseEvent e) {
    Point p = ((Component) e.getSource()).getLocation();
    Object[] params = {new Integer(p.x + e.getX()), new Integer(p.y + e.getY())};
    mouseMotionSupport.notify(params);
  }
  }

  /**
   * Creates a ShapeComponent for the given Shape object, and puts
   * it on the canvas.
   *
   * @param s an object of type 'Shape'
   * @return the ShapeComponent that will draw the given shape on the screen 
   */
  public synchronized Component add(Shape s) {
    return add(new ShapeComponent(s));
  }

  /**
   * Puts the given Component on the canvas using the Component's preferred
   * size.
   * The location of the component is not set.
   *
   * @param c the Component to be added
   * @return the given Component is returned for convenience
   */
  public synchronized Component add(Component c) {
    if (drawingPanel == c.getParent()) {
      System.out.println("\nWARNING from add(" + c + ") in CS101Canvas:\n" +
			 "   The component was already on the canvas.");
    } else {
      c.setSize(c.getPreferredSize());
      drawingPanel.add(c, JLayeredPane.DEFAULT_LAYER);
      c.addMouseListener(mouseListener);
      c.addMouseMotionListener(mouseListener);
    }
    return c;
  }


  /**
   * Puts the given Component on the canvas using the Component's preferred
   * size at the given x,y location.
   *
   * @param c the Component to be added
   * @param x the x position for the upper left of the Component
   * @param y the y position for the upper left of the Component
   * @return the given Component is returned for convenience
   */
  public synchronized Component add(Component c, int x, int y) {
    c.setLocation(x,y);
    return add(c);
  }

  /**
   * Takes the given Component off the canvas.
   *
   * @param c the Component to be removed
   */
  public synchronized void remove(Component c) {
    if (drawingPanel == c.getParent()) {
      drawingPanel.remove(c);
      drawingPanel.repaint();
      c.removeMouseListener(mouseListener);
      c.removeMouseMotionListener(mouseListener);
      if (movingComponentsMap.containsKey(c))
	movingComponentsMap.remove(c);
    } else {
      System.out.println("\nWARNING from remove(" + c + ") in CS101Canvas:\n" +
			 "   The component was not on the canvas.");
    }
  }

  /**
   * Moves the given Component on top of all other Components.
   *
   * @param c the Component to be moved to the front
   */
  public synchronized void moveToFront(Component c) {
    drawingPanel.moveToFront(c);
  }

  /**
   * Changes the layer of a component.
   *
   * @param c the Component
   * @param layer the new layer for the Component
   */
  synchronized void setLayer(Component c, int layer) {
    drawingPanel.setLayer(c,layer);
  }

  /**
   * Moves the given Component behind of all other Components.
   *
   * @param c the Component to be moved to the back
   */
  public synchronized void moveToBack(Component c) {
    drawingPanel.moveToBack(c);
  }

  /**
   * Moves the given component to the given x,y position in a
   * straight-line smooth motion animation lasting approximately
   * the given length of time.  Note: the Component's setLocation
   * method should be called instead when the component is to move
   * instantly, without smooth animation.
   *
   * @param c what should be moved
   * @param newX the destination x coordinate
   * @param newY the destination y coordinate
   * @param milliseconds the desired length of time for the animation
   */
  public synchronized void smoothMove(final Component c,
				      final int newX,
				      final int newY,
				      int milliseconds) {
    Point cur = c.getLocation();
    if (newX != cur.x || newY != cur.y) {
      movingComponentsMap.put(c, new MoveData(cur.x, cur.y,
					      newX, newY, milliseconds));
      notify();
    }
  }

  void moveComponentsAsNeeded() {
    while (true) {
      takeOneStep();
      sleep(movingDelay);
    }
  }

  synchronized void takeOneStep() {
    if (movingComponents.isEmpty()) {
      try {
	wait();
      } catch (InterruptedException ie) {}
    }
    Iterator movingData = movingComponents.iterator();
    while (movingData.hasNext()) {
      Map.Entry data = (Map.Entry) movingData.next();
      Component c = (Component) data.getKey();
      MoveData md = (MoveData) data.getValue();
      if (md.updateToDestination())
	movingData.remove();
      c.setLocation((int) md.curX, (int) md.curY);
      c.repaint();
    }
  }

  class MoveData {
    double curX, curY, deltaX, deltaY, newX, newY;
    MoveData(double curX, double curY,
	     double newX, double newY, int milliseconds) {
      this.curX = curX;  this.curY = curY;
      this.newX = newX;  this.newY = newY;
      int steps = Math.max(milliseconds / movingDelay, 1);
      deltaX = (newX - curX) / steps;
      deltaY = (newY - curY) / steps;
    }
    boolean updateToDestination() {
	 if ((Math.abs(newX - curX) <= Math.abs(deltaX)) &&
	     (Math.abs(newY - curY) <= Math.abs(deltaY))) {
	   curX = newX;
	   curY = newY;
	   return true;
	 } else {
	   curX += deltaX;
	   curY += deltaY;
	   return false;
	 }
    }
  } // MoveData

  /**
   * Creates a time delay of approximately the given length.
   *
   * @param milliseconds the desired length of the delay, in milliseconds
   */
  public void sleep(int milliseconds) {
    try {
      Thread.sleep(milliseconds);
    } catch (InterruptedException ie) {
    }
  }
} // CS101Canvas


  






