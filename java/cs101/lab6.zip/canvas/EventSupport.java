package canvas;

/**
 * EventSupport.java
 *
 *
 * Created: Wed Sep 01 16:33:41 1999
 *
 * @author Kenneth J. Goldman 
 * @version 1.0
 */

import java.util.*;
import java.lang.reflect.*;

class EventSupport  {
  String methodName;
  Class[] paramTypes;
  LinkedList targets;
  LinkedList methods;
  
  public EventSupport(String methodName, Class[] paramTypes) {
    this.methodName = methodName;
    this.paramTypes = paramTypes;
    targets = new LinkedList();
    methods = new LinkedList();
  }

  public String getNotificationMethodSignature() {
    String result = methodName + "(";
    for (int i = 0; i < paramTypes.length; i++) {
      if (i > 0)
	result += ", ";
      result += typeName(paramTypes[i]);
    }
    result += ")";
    return result;
  }

  public String typeName(Class c) {
    if (c.isArray()) {
      return typeName(c.getComponentType()) + "[]";
    } else {
      return c.getName();
    }
  }

  public synchronized void addListener(Object target) {
    if (target != null && !targets.contains(target)) {
      try {
	Method m = target.getClass().getMethod(methodName, paramTypes);
	targets.add(target);
	methods.add(m);
      } catch (NoSuchMethodException nsme) {
	System.out.println("WARNING: Listener " + target + " was not added because the required " +
			   "method\n    public void " + getNotificationMethodSignature() +
			   " is not implemented.\n" + nsme);
      } catch (SecurityException se) {
	System.out.println("WARNING: Listener " + target + " was not added because the required " +
			   "method\n    public void " + getNotificationMethodSignature() +
			   " is not accessible.\n" + se);
      }
    }
  }
  
  public synchronized void removeListener(Object target) {
    int i = targets.indexOf(target);
    if (i >= 0) {
      targets.remove(i);
      methods.remove(i);
    }
  }

  public synchronized void notify(final Object[] parameters) {
    LinkedList threadList = new LinkedList();
    Iterator ts = targets.listIterator();
    Iterator ms = methods.listIterator();
    while (ts.hasNext()) {
      threadList.add(new Notifier((Method) ms.next(),
				  ts.next(),
				  parameters));
    }
    Iterator it = threadList.listIterator();
    while (it.hasNext()) {
      ((Thread) (it.next())).start();
    }
  }

  class Notifier extends Thread {
    Method method;
    Object target;
    Object[] parameters;

    Notifier(Method method, Object target, Object[] parameters) {
      this.method = method;
      this.target = target;
      this.parameters = parameters;
    }
    public void run() {
      try {
	method.invoke(target,parameters);
      } catch (InvocationTargetException ite) {
	System.out.println("\nException occurred during event processing:");
	ite.getTargetException().printStackTrace();
      } catch (Exception e) {
	System.out.println("\nException occurred during event processing:");
	e.printStackTrace();
      }
    }
  }   
} // EventSupport
