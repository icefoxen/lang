//  Name:
//  Lab Section:
//  Email:
//  CS101 Lab 6
//  Lab6.java
//  Date:

public class Lab6 extends Thread {

  public void run() {
    System.out.println("CS101 Lab 6 by **PUT YOUR NAME HERE** \n");
	
    // You can use the following lists for some of your tests, but
    // you should also create some of your own lists of various lengths
    // and with various values.
    ListItem a = new ListItem(1, new ListItem(2, new ListItem(3, null)));
    ListItem b = new ListItem(6, new ListItem(8, new ListItem(6, null)));
    ListItem c = new ListItem(30, null);
    ListItem d = null;
    
    System.out.println("a = " + a);
    System.out.println("b = " + b);
    System.out.println("c = " + c);
    System.out.println("d = " + d);

    // PUT YOUR TESTS HERE

    System.out.println("... finished testing.");
  }

  public static void main(String args[]) {
    (new Lab6()).start();
  }

}

