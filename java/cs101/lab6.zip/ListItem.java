//  Name:
//  Lab Section:
//  Email:
//  CS101 Lab 6
//  ListItem.java
//  Date:

import canvas.*;

public class ListItem {
  private static CS101Canvas screen = new CS101Canvas(); // for showing lists

  public int number;
  public ListItem next;

  ListItem(int number, ListItem next) {
    this.number = number;
    this.next = next;
    screen.showData(this);
  }

  // put your ListItem methods here (problem 1)

  public String toString() {
    if (next == null)
      return ("" + number);
    else
      return ("" + number + " " + next);
  }

  // call this method to start showing lists on a different canvas
  static void startNewDisplay() { 
    screen = new CS101Canvas();
  }

}
